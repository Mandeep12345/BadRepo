﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LibraryManagementSystem
{
    public partial class Admin_Librarian2 : System.Web.UI.Page
    {
        static string connString = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnAddLibrarian_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "INSERT INTO [dbo].[Librarian] ([lib_name], [lib_pass]) VALUES (@name, @pass)";
                try
                {
                    int pass = GetPassword();
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    CMD.Parameters.AddWithValue("@name", TxtAddName.Text);
                    CMD.Parameters.AddWithValue("@pass", pass.ToString());
                    int res = CMD.ExecuteNonQuery();
                    if (res > 0)
                    {

                    }
                    else
                    {

                    }
                }
                catch (SqlException E)
                {

                }
            }
        }

        private int GetPassword()
        {
            return new Random().Next(1000,9999);
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "Update Librarian SET lib_name=@name WHERE m_id=@id";
                try
                {
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    CMD.Parameters.AddWithValue("@name", TxtUpdName.Text);
                    CMD.Parameters.AddWithValue("@id", DdlUpdLib.SelectedValue);
                    int res = CMD.ExecuteNonQuery();
                    if (res > 0)
                    {

                    }
                    else
                    {

                    }
                }
                catch (SqlException E)
                {

                }
            }
        }

        protected void btnDelLib_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "DELETE Librarian WHERE m_id=@id";
                try
                {
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    CMD.Parameters.AddWithValue("@id", DdlDelLib.SelectedValue);
                    int res = CMD.ExecuteNonQuery();
                    if (res > 0)
                    {

                    }
                    else
                    {

                    }
                }
                catch (SqlException E)
                {

                }
            }
        }
        protected void DdlUpdLib_SelectedIndexChanged(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "SELECT * FROM Librarian WHERE lib_id=@id";
                try
                {
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    CMD.Parameters.AddWithValue("@id", DdlUpdLib.SelectedValue);
                    SqlDataReader SD = CMD.ExecuteReader();
                    while (SD.Read())
                    {
                        TxtUpdName.Text = SD["lib_name"].ToString();
                    }
                }
                catch (SqlException E)
                {

                }
            }
        }
    }
}