﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LibraryManagementSystem
{
    public partial class Librarian_Report : System.Web.UI.Page
    {
        static string connString = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnGetReport_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "";
                
                switch (DdlReport.SelectedIndex)
                {
                    case 0:
                        query = "SELECT  Book.b_id AS # ,Author.auth_name AS Author, Book.book_name AS Title, Book.ISBN, Category.cat_name AS Category, Publisher.pub_name AS Publisher, Book.b_quantity AS Stock FROM Author INNER JOIN Book ON Author.auth_id = Book.auth_id INNER JOIN Category ON Book.cat_id = Category.cat_id INNER JOIN Publisher ON Book.pub_id = Publisher.pub_id";
                        break;
                    case 1:
                        query = "SELECT auth_id AS ID# ,auth_name AS Author FROM Author";
                        break;
                    case 2:
                        query = "SELECT pub_id AS ID# ,pub_name AS Publisher FROM Publisher";
                        break;
                    case 3:
                        query = "SELECT cat_id AS ID# ,cat_name AS Category FROM Category";
                        break;
                    case 4:
                        query = "SELECT  Book.isbn AS ISBN, Book.book_name, Book_Issue.status FROM Book INNER JOIN Book_Issue ON Book.isbn=Book_Issue.isbn WHERE Book_Issue.status = 'issued'";
                        break;
                    case 5:
                        query = "SELECT  Book.isbn AS ISBN, Book.book_name, Book_Issue.status FROM Book INNER JOIN Book_Issue ON Book.isbn=Book_Issue.isbn WHERE Book_Issue.status = 'issued' AND Book_Issue.duedate < @date" ;
                        break;


                }
                
                try
                {
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    CMD.Parameters.AddWithValue("@date", DateTime.Now.Date);
                    SqlDataReader SD = CMD.ExecuteReader();
                    gridReport.DataSource = SD;
                    gridReport.DataBind();
                }
                catch (SqlException E)
                {

                }
            }
        }
    }
}