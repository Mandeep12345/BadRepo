﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LibraryManagementSystem
{
    public partial class Member_Profile : System.Web.UI.Page
    {
        static string connString = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;
        private int USER_ID = -1;

        protected void Page_Load(object sender, EventArgs e)
        {

            USER_ID = Convert.ToInt32(Session["user_id"]);
            if (!IsPostBack)
            {
                string query = "SELECT m_img FROM Member where m_id=@Id";

                using (SqlConnection conn = new SqlConnection(connString))
                {
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@Id", USER_ID);
                    conn.Open();

                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        string url = reader["m_img"].ToString();
                        ImgProfile.ImageUrl = "~/Resources/" + url;
                        reader.Close();
                    }
                }
            }

        }

        protected void btnUpdPic_Click(object sender, EventArgs e)
        {
            if (FileUpload1.HasFile)
            {
                string fileName = FileUpload1.FileName;
                string fileExtension = Path.GetExtension(fileName);

                // check for the file extension
                if (fileExtension.ToLower() == ".jpg" || fileExtension.ToLower() == ".png" || fileExtension.ToLower() == ".jpeg")
                {
                    // get file size, in bytes
                    int fileSize = FileUpload1.PostedFile.ContentLength;

                    // if file size less than or equal to 2MB
                    if (fileSize <= 2097152)
                    {
                        FileUpload1.SaveAs(Server.MapPath("~/Resources/") + fileName);
                        labelInfo.Text = "File successfully uploaded";
                        labelInfo.ForeColor = Color.Green;
                        int res = UpdateProfilePic(fileName);
                        if (res > 0)
                            labelInfo.Text = "Success";
                        else
                            labelInfo.Text = "Error Occured";
                    }
                    else
                    {
                        labelInfo.Text = "File size exceeds the limit of 2MB";
                        labelInfo.ForeColor = Color.Red;
                    }
                }
                else
                {
                    labelInfo.Text = "Only JPG, JPEG and PNG are supported";
                    labelInfo.ForeColor = Color.Red;
                }
            }
        }

        private int UpdateProfilePic(string filename)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "UPDATE member SET m_img=@path WHERE m_id=@id";

                try
                {
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    CMD.Parameters.AddWithValue("@path", filename);
                    CMD.Parameters.AddWithValue("@id", USER_ID);
                    int res = CMD.ExecuteNonQuery();
                    return res;
                }
                catch (SqlException E)
                {

                }
            }
            return 0;
        }

        protected void btnUpdatePassword_Click(object sender, EventArgs e)
        {
            UpdatePassword(TxtPass.Text);
        }

        private void UpdatePassword(string pass)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "UPDATE member SET m_pass=@pass WHERE m_id=@id";

                try
                {
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    CMD.Parameters.AddWithValue("@pass", pass);
                    CMD.Parameters.AddWithValue("@id", USER_ID);
                    int res = CMD.ExecuteNonQuery();
                    if (res > 0)
                    {
                        LblPass.Text = "Password Updated Successfully";
                    }
                    else
                    {
                        LblPass.Text = "Error Occured";
                    }
                }
                catch (SqlException E)
                {

                }
            }
        }

        protected void bntUpdtPhn_Click(object sender, EventArgs e)
        {
            UpdatePhoneNumber(TxtPhone.Text);
        }

        private void UpdatePhoneNumber(string phone)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "UPDATE member SET m_phn=@phn WHERE m_id=@id";

                try
                {
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    CMD.Parameters.AddWithValue("@phn", phone);
                    CMD.Parameters.AddWithValue("@id", USER_ID);
                    int res = CMD.ExecuteNonQuery();
                    if (res > 0)
                    {
                        LblPhn.Text = "Phone Number Updated Successfully";
                    }
                    else
                    {
                        LblPhn.Text = "Error Occured";
                    }
                }
                catch (SqlException E)
                {

                }
            }
        }

        protected void btnDeactivateAcc_Click(object sender, EventArgs e)
        {
            SendDeactivationRequest();
        }

        private void SendDeactivationRequest()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "UPDATE member SET m_status=@status WHERE m_id=@id";

                try
                {
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    CMD.Parameters.AddWithValue("@status", "pending");
                    CMD.Parameters.AddWithValue("@id", USER_ID);
                    int res = CMD.ExecuteNonQuery();
                    if (res > 0)
                    {
                        LblDeact.Text = "Deactivation Request Send Successfully";
                    }
                    else
                    {
                        LblDeact.Text = "Error Occured";
                    }
                }
                catch (SqlException E)
                {

                }
            }
        }
    }
}