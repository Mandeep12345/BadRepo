﻿using System.Web.UI;

namespace LibraryManagementSystem.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}