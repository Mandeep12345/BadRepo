﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LibraryManagementSystem
{
    public partial class Admin_Publisher : System.Web.UI.Page
    {
        static string connString = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnAddPub_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "INSERT INTO Publisher ([pub_name]) VALUES (@name)";
                try
                {
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    CMD.Parameters.AddWithValue("@name", TxtPubName.Text);
                    int res = CMD.ExecuteNonQuery();
                    if (res > 0)
                    {

                    }
                    else
                    {

                    }
                }
                catch (SqlException E)
                {

                }
            }

        }

        protected void BtnUpdPub_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "Update Publisher SET pub_name=@name WHERE pub_id=@id";
                try
                {
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    CMD.Parameters.AddWithValue("@name", TxtUpdPub.Text);
                    CMD.Parameters.AddWithValue("@id", DdlUpdPub.SelectedValue);
                    int res = CMD.ExecuteNonQuery();
                    if (res > 0)
                    {

                    }
                    else
                    {

                    }
                }
                catch (SqlException E)
                {

                }
            }
        }

        protected void btnDelPub_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "DELETE Publisher WHERE pub_id=@id";
                try
                {
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    CMD.Parameters.AddWithValue("@id", DdlDelPub.SelectedValue);
                    int res = CMD.ExecuteNonQuery();
                    if (res > 0)
                    {

                    }
                    else
                    {

                    }
                }
                catch (SqlException E)
                {

                }
            }
        }

        protected void DdlUpdPub_SelectedIndexChanged(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "SELECT * FROM Publisher WHERE pub_id=@id";
                try
                {
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    CMD.Parameters.AddWithValue("@id", DdlUpdPub.SelectedValue);
                    SqlDataReader SD = CMD.ExecuteReader();
                    while (SD.Read())
                    {
                        TxtUpdPub.Text = SD["pub_name"].ToString();
                    }
                }
                catch (SqlException E)
                {

                }
            }
        }

    }
}