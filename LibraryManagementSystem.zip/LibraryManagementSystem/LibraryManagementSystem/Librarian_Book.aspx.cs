﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LibraryManagementSystem
{

    public partial class Librarian_Book : System.Web.UI.Page
    {
        static string connString = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

            }
        }

        protected void btnIssueBook_Click(object sender, EventArgs e)
        {
            foreach(GridViewRow row in gridIssue.Rows)
            {
                DropDownList D =(DropDownList)row.FindControl("DdlStat");
                if(D.SelectedValue == "issued")
                {
                    UpdateStatus(row.Cells[0].Text);
                }

                LblInfo.Visible = true  ;
            }
        }

        private void UpdateStatus(string id)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "Update Book_Issue SET status=@status WHERE bi_id=@id";
                try
                {
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    CMD.Parameters.AddWithValue("@id", id);
                    CMD.Parameters.AddWithValue("@status", "issued");
                    int res = CMD.ExecuteNonQuery();
                    if (res > 0)
                    {

                    }
                    else
                    {

                    }
                }
                catch (SqlException E)
                {

                }
            }

        }

        protected void btnRetBook_Click(object sender, EventArgs e)
        {
            foreach (GridViewRow row in gridIssue.Rows)
            {
                CheckBox c = (CheckBox)row.FindControl("ChkBox");
                
                if (c.Checked)
                {
                    UpdateFineStatus(row.Cells[0].Text, row.Cells[7].Text);
                }
            }
        }

        private void UpdateFineStatus(string id, string bi_id)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "Update Return_Book SET status=@status WHERE bi_id=@id";
                try
                {
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    CMD.Parameters.AddWithValue("@id", id);
                    CMD.Parameters.AddWithValue("@status", "returned");
                    int res = CMD.ExecuteNonQuery();
                    if (res > 0)
                    {
                        DeleteFromIssueTbl(bi_id);
                    }
                    else
                    {

                    }
                }
                catch (SqlException E)
                {

                }
            }

        }

        private void DeleteFromIssueTbl(string id)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "";
                query = "DELETE FROM Book_Issue WHERE bi_id =@id";
                try
                {
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    CMD.Parameters.AddWithValue("@id", id);
                    int res = CMD.ExecuteNonQuery();
                    if (res > 0)
                    {
                    }
                    else
                    {
                    }
                }
                catch (SqlException E)
                {

                }
            }
            
        }
    }
}