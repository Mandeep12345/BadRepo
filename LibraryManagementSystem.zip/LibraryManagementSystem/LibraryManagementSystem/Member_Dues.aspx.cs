﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LibraryManagementSystem
{
    public partial class Member_Dues : System.Web.UI.Page
    {
        private int USER_ID= -1;
        static string connString = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            USER_ID = Convert.ToInt32(Session["user_id"]);
        }

        protected void btnViewDues_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "";

                if (DropDwnDues.SelectedIndex == 0)
                {
                    query = "SELECT Book.book_name AS TITLE, Return_Book.fine AS FINE_DUE, Return_Book.ret_date AS RETURN_DATE FROM Book Inner Join Return_Book On Book.isbn = Return_Book.isbn WHERE Return_Book.mem_id = @mid AND Return_Book.fine_status = 'due' ";
                }
                if (DropDwnDues.SelectedIndex == 1)
                {
                    query = "SELECT Book.book_name AS TITLE, Return_Book.fine AS FINE_DUE, Return_Book.ret_date AS RETURN_DATE FROM Book Inner Join Return_Book On Book.isbn = Return_Book.isbn WHERE Return_Book.mem_id = @mid AND Return_Book.fine_status <> 'due' ";
                }

                try
                {
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    CMD.Parameters.Add("@mid", USER_ID);
                    SqlDataReader SD = CMD.ExecuteReader();
                    if(!SD.HasRows)
                    {
                        LblInfoViewDues.Visible = true;
                    }
                    else
                    {
                        LblInfoViewDues.Visible = false;
                    }
                    gridDues.DataSource = SD;
                    gridDues.DataBind();
                    SD.Close();
                }
                catch (SqlException E)
                {

                }
            }
        }
    }
}