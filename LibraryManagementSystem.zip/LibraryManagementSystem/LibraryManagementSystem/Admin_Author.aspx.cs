﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LibraryManagementSystem
{
    public partial class Admin_Author : System.Web.UI.Page
    {
        static string connString = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void BtnAddAuth_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "INSERT INTO Author ([auth_name]) VALUES (@name)";
                try
                {
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    CMD.Parameters.AddWithValue("@name", TxtAuthName.Text);
                    int res = CMD.ExecuteNonQuery();
                    if(res > 0)
                    {

                    }
                    else
                    {

                    }
                }
                catch (SqlException E)
                {

                }
            }
        }

        protected void btnUpdateAuth_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "Update Author SET auth_name=@name WHERE auth_id=@id";
                try
                {
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    CMD.Parameters.AddWithValue("@name", TxtUpdateName.Text);
                    CMD.Parameters.AddWithValue("@id", DdlUpdateId.SelectedValue);
                    int res = CMD.ExecuteNonQuery();
                    if (res > 0)
                    {

                    }
                    else
                    {

                    }
                }
                catch (SqlException E)
                {

                }
            }
        }

        protected void btnDelAuth_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "DELETE Author WHERE auth_id=@id";
                try
                {
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    CMD.Parameters.AddWithValue("@name", TxtUpdateName.Text);
                    CMD.Parameters.AddWithValue("@id", DdlUpdateId.SelectedValue);
                    int res = CMD.ExecuteNonQuery();
                    if (res > 0)
                    {

                    }
                    else
                    {

                    }
                }
                catch (SqlException E)
                {

                }
            }
        }

        protected void DdlUpdateId_SelectedIndexChanged(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "SELECT * FROM AUTHOR WHERE auth_id=@id";
                try
                {
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    CMD.Parameters.AddWithValue("@id", DdlUpdateId.SelectedValue);
                    SqlDataReader SD = CMD.ExecuteReader();
                    while (SD.Read())
                    {
                        TxtUpdateName.Text = SD["auth_name"].ToString() ;
                    }
                }
                catch (SqlException E)
                {

                }
            }
        }
    }
}