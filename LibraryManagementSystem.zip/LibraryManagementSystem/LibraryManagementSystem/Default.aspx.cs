﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LibraryManagementSystem
{
    public partial class _Default : Page
    {
        static string connString = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Unnamed_Click(object sender, EventArgs e)
        {
            if (Rbadmin.Checked == true && TxtName.Text == "Admin" && TxtPass.Text == "Admin")
            {
                Response.Redirect("Admin_Book.aspx");
            }
        
            if (RbLibrarian.Checked) {
                CheckForLibrarian();
            }
            if (RbMember.Checked)
            {
                CheckForMember();
            }
            else
            {
                LblInfoLogin.Visible = true;
            }
            
    }

        private void CheckForMember()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "SELECT * FROM MEMBER WHERE m_name=@name AND m_pass=@pass";
                try
                {
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    CMD.Parameters.Add("@name", TxtName.Text);
                    CMD.Parameters.Add("@pass", TxtPass.Text);
                    SqlDataReader SD = CMD.ExecuteReader();
                    if (!SD.HasRows)
                    {
                    
                        LblInfoLogin.Visible = true;
                    }
                    else
                    {
                        while (SD.Read())
                        {
                            Session["user_id"] = SD["m_id"];
                            Response.Redirect("Member_Books.aspx");
                        }

                        LblInfoLogin.Visible = false;
                    }

                }
                catch (SqlException E)
                {

                }
            }
        }

        private void CheckForLibrarian()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "SELECT * FROM Librarian WHERE lib_name=@name AND lib_pass=@pass";
                try
                {
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    CMD.Parameters.Add("@name", TxtName.Text);
                    CMD.Parameters.Add("@pass", TxtPass.Text);
                    SqlDataReader SD = CMD.ExecuteReader();
                    if (!SD.HasRows)
                    {
                        LblInfoLogin.Visible = true;
                    }
                    else
                    {
                        LblInfoLogin.Visible = false;
                        Response.Redirect("Librarian_Book.aspx");
                    }
                    
                }
                catch (SqlException E)
                {

                }
            }

        }
    }
}