﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LibraryManagementSystem
{
    public partial class Member_Books : System.Web.UI.Page
    {
        static string connString = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;
        private double PerDayFine = 5;
        private static int USER_ID =0 ;
        private int BOOK_LIMIT = 5;
        private int RE_ISSUE_LIMIT = 2;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                USER_ID = Convert.ToInt32(Session["user_id"]);

                using (SqlConnection conn = new SqlConnection(connString))
                {

                    string query2 = "SELECT bi_id FROM Book_Issue WHERE (mem_id = @id) AND(status = 'issued')";

                    try
                    {
                        conn.Open();
                        SqlCommand CMD = new SqlCommand(query2, conn);
                        CMD.Parameters.AddWithValue("@id", USER_ID);
                        SqlDataReader SD = CMD.ExecuteReader();
                        if (!SD.HasRows)
                        {
                            DropDwnIsbnRet.Enabled = false;
                        }
                        else
                        {

                            DropDwnIsbnRet.Enabled = true;
                        }
                        DropDwnIsbnRet.DataSource = SD;
                        DropDwnIsbnRet.DataTextField = "bi_id";
                        DropDwnIsbnRet.DataValueField = "bi_id";
                        DropDwnIsbnRet.DataBind();
                        SD.Close();
                    }
                    catch (SqlException E)
                    {

                    }
                }
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    string query = "";
                    query = "SELECT  Book.b_id AS # ,Author.auth_name AS Author, Book.book_name AS Title, Book.ISBN, Category.cat_name AS Category, Publisher.pub_name AS Publisher, Book.b_quantity AS Stock FROM Author INNER JOIN Book ON Author.auth_id = Book.auth_id INNER JOIN Category ON Book.cat_id = Category.cat_id INNER JOIN Publisher ON Book.pub_id = Publisher.pub_id";
                    try
                    {
                        conn.Open();
                        SqlCommand CMD = new SqlCommand(query, conn);
                        SqlDataReader SD = CMD.ExecuteReader();
                        if (!SD.HasRows)
                        {
                            LblInfo.Visible = true;
                        }
                        else
                        {
                            LblInfo.Visible = false;
                        }
                        gridBooks.DataSource = SD;
                        gridBooks.DataBind();
                    }
                    catch (SqlException E)
                    {

                    }
                }
            }

        }

        protected void BtnSearchBook_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "";

                switch (DdlSearch.SelectedIndex)
                {
                    case 0:
                        query = "SELECT  Book.b_id AS # ,Author.auth_name AS Author, Book.book_name AS Title, Book.ISBN, Category.cat_name AS Category, Publisher.pub_name AS Publisher, Book.b_quantity AS Stock FROM Author INNER JOIN Book ON Author.auth_id = Book.auth_id INNER JOIN Category ON Book.cat_id = Category.cat_id INNER JOIN Publisher ON Book.pub_id = Publisher.pub_id WHERE Book.book_name Like '" + TxtSearch.Value + "%'";
                        break;
                    case 1:
                        query = "SELECT  Book.b_id AS # ,Author.auth_name AS Author, Book.book_name AS Title, Book.ISBN, Category.cat_name AS Category, Publisher.pub_name AS Publisher, Book.b_quantity AS Stock FROM Author INNER JOIN Book ON Author.auth_id = Book.auth_id INNER JOIN Category ON Book.cat_id = Category.cat_id INNER JOIN Publisher ON Book.pub_id = Publisher.pub_id WHERE Author.auth_name Like '" + TxtSearch.Value + "%'";
                        break;
                    case 2:
                        query = "SELECT  Book.b_id AS # ,Author.auth_name AS Author, Book.book_name AS Title, Book.ISBN, Category.cat_name AS Category, Publisher.pub_name AS Publisher, Book.b_quantity AS Stock FROM Author INNER JOIN Book ON Author.auth_id = Book.auth_id INNER JOIN Category ON Book.cat_id = Category.cat_id INNER JOIN Publisher ON Book.pub_id = Publisher.pub_id WHERE Publisher.pub_name Like '" + TxtSearch.Value + "%'";
                        break;
                    case 3:
                        query = "SELECT  Book.b_id AS # ,Author.auth_name AS Author, Book.book_name AS Title, Book.ISBN, Category.cat_name AS Category, Publisher.pub_name AS Publisher, Book.b_quantity AS Stock FROM Author INNER JOIN Book ON Author.auth_id = Book.auth_id INNER JOIN Category ON Book.cat_id = Category.cat_id INNER JOIN Publisher ON Book.pub_id = Publisher.pub_id WHERE Category.cat_name Like '" + TxtSearch.Value + "%'";
                        break;

                }
                try
                {
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    SqlDataReader SD = CMD.ExecuteReader();
                    if (!SD.HasRows)
                    {
                        LblInfo.Visible = true;
                    }
                    else
                    {
                        LblInfo.Visible = false;
                    }
                    gridBooks.DataSource = SD;
                    gridBooks.DataBind();
                    SD.Close();
                }
                catch (SqlException E)
                {

                }
            }

            
        }

        protected void DropDwnIsbn_SelectedIndexChanged(object sender, EventArgs e)
        {

            LblInfoReq.Visible = false;
        }

        protected void btnSendReq_Click(object sender, EventArgs e)
        {
            int BookIssued = 0;
            BookIssued = GetBookIssuedNumber();
            int BookReIssueNumber = 0;
            BookReIssueNumber = GetReissueNumber();
            if (BOOK_LIMIT > BookIssued && RE_ISSUE_LIMIT > BookReIssueNumber){ 
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    DateTime expiryDate = DateTime.Today.AddDays(30);
                    string query = "INSERT INTO [dbo].[Book_Issue] ([mem_id], [ISBN], [status], [duedate]) VALUES (@mid, @isbn,@status, @date)";
                    try
                    {
                        conn.Open();
                        SqlCommand CMD = new SqlCommand(query, conn);
                        CMD.Parameters.AddWithValue("@isbn", DropDwnIsbn.SelectedValue);
                        CMD.Parameters.AddWithValue("@mid", USER_ID);
                        CMD.Parameters.AddWithValue("@status", "pending");
                        CMD.Parameters.AddWithValue("@date", expiryDate.Date);

                        int res = CMD.ExecuteNonQuery();
                        if (res > 0)
                        {
                            LblInfoReq.Visible = true;
                        }
                    }
                    catch (SqlException E)
                    {

                    }
                }
            }
            else
            {
               LblInfoReq.Visible = true;
                LblInfoReq.Text = "Your Limit Is Reached";
            }
        }

        private int GetReissueNumber()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "";
                int count = 0;
                query = "SELECT Count(*) FROM Book_Issue WHERE mem_id = @mid AND isbn=@isbn";
                try
                {
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    CMD.Parameters.Add("@mid", USER_ID);
                    CMD.Parameters.Add("@isbn", DropDwnIsbn.SelectedValue);
                    count = (int)CMD.ExecuteScalar();
                }
                catch (SqlException E){}
                return count;
            }
        }

        private int GetBookIssuedNumber()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "";
                int count = 0;
                query = "SELECT Count(*) FROM Book_Issue WHERE mem_id =" + USER_ID;
                try
                {
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    count = (int)CMD.ExecuteScalar();
                }
                catch (SqlException E)
                {

                }
                return count;
            }
        }

        protected void DropDwnIsbnRet_SelectedIndexChanged(object sender, EventArgs e)
        {
            //using (SqlConnection conn = new SqlConnection(connString))
            //{
            //    string query = "";
            //    query = "SELECT Book.book_name, Book.isbn, Book_Issue.duedate From Book Inner Join Book_Issue On Book.b_id = Book_Issue.bi_id WHERE Book_Issue.mem_id = 2 And Book.isbn ="+DropDwnIsbnRet.SelectedValue ;
            //    //query = "SELECT * FROM book";
            //    try
            //    {
            //        conn.Open();
            //        SqlCommand CMD = new SqlCommand(query, conn);
            //        SqlDataReader SD = CMD.ExecuteReader();
                    
            //        gridIssuedBook.DataSource = SD;
            //        gridIssuedBook.DataBind();
            //    }
            //    catch (SqlException E)
            //    {

            //    }
            //}
        }

        protected void btnRetReq_Click(object sender, EventArgs e)
        {
            
            using (SqlConnection conn = new SqlConnection(connString))
            {
                int Fine = CalculateFine();
                int ISBN = GetISBN();
                string query = "";
                query = "INSERT INTO [dbo].[Return_Book] ([mem_id], [ISBN], [status], [fine], [ret_date], [bi_id], [fine_status]) VALUES (@mid, @isbn, @status, @fine, @retDate, @biid, @fstatus)";
                try
                {
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    CMD.Parameters.Add("@mid", USER_ID);
                    CMD.Parameters.Add("@isbn", ISBN);
                    CMD.Parameters.Add("@fine", Fine);
                    CMD.Parameters.Add("@biid", DropDwnIsbnRet.SelectedValue);
                    CMD.Parameters.Add("@status", "pending");
                    CMD.Parameters.Add("@fstatus", "due");
                    CMD.Parameters.Add("@retDate", DateTime.Now.Date);
                    int res = CMD.ExecuteNonQuery();
                    if(res > 0)
                    {
                        LblInfoRet.Visible = true;
                    }
                    else
                    {
                        LblInfoRet.Visible = false;
                    }
                }
                catch (SqlException E)
                {

                }
            }
        }

        private int GetISBN()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "";
                int isbn = 0;
                query = "SELECT isbn FROM Book_Issue WHERE bi_id =" + DropDwnIsbnRet.SelectedValue;
                try
                {
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    SqlDataReader SD = CMD.ExecuteReader();
                    while (SD.Read())
                    {
                        isbn = Convert.ToInt32(SD["isbn"]);
                    }
                }
                catch (SqlException E)
                {

                }
                return isbn;
            }
        }

        private void DeleteRecFromIssueTable()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                int Fine = CalculateFine();
                string query = "";
                query = "DELETE FROM Book_Issue WHERE bi_id =" + DropDwnIsbnRet.SelectedValue;
                try
                {
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    int res = CMD.ExecuteNonQuery();
                    if (res > 0)
                    {
                        LblInfoRet.Visible = true;
                    }
                    else
                    {
                        LblInfoRet.Visible = false;
                    }
                }
                catch (SqlException E)
                {

                }
            }
        }

        private int CalculateFine()
        {
            DateTime dueDate = DateTime.Now;
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "";
                query = "SELECT duedate From Book_Issue WHERE mem_id = @mid And bi_id =" + DropDwnIsbnRet.SelectedValue;
                try
                {
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    CMD.Parameters.Add("@mid", USER_ID);
                    SqlDataReader SD = CMD.ExecuteReader();
                    while (SD.Read())
                    {
                        dueDate = Convert.ToDateTime(SD["duedate"]);
                    }
                }
                catch (SqlException E)
                {

                }
            }

           double days = (DateTime.Now.Date - dueDate.Date).TotalDays;
            if (days > 0)
                return (int)(PerDayFine * days);
            else
                return 0;

        }

        protected void btnViewBooks_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "";

                if (DropDwnViewBook.SelectedIndex == 0)
                {
                    query = "SELECT Book.book_name, Book_Issue.duedate FROM Book_Issue Inner Join Book On Book.isbn = Book_Issue.isbn WHERE Book_Issue.status = 'issued' AND Book_issue.mem_id="+USER_ID;
                }
                if (DropDwnViewBook.SelectedIndex == 1)
                {
                    query = "SELECT Book.book_name, Return_Book.ret_date FROM Return_Book Inner Join Book On Book.isbn = Return_Book.isbn WHERE Return_Book.status = 'returned' AND Return_Book.mem_id =" + USER_ID;
                }
                
                try
                {
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    SqlDataReader SD = CMD.ExecuteReader();
                    if (!SD.HasRows)
                    {
                        LblInfoViewBook.Visible = true;
                    }
                    else
                    {
                        LblInfoViewBook.Visible = false;
                    }
                    gridPrevBooks.DataSource = SD;
                    gridPrevBooks.DataBind();
                    SD.Close();
                }
                catch (SqlException E)
                {

                }
            }
        }
    }
    
}

