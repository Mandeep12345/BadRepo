﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LibraryManagementSystem
{
    public partial class Admin_Category : System.Web.UI.Page
    {
        static string connString = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnAddCat_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "INSERT INTO Category ([cat_name]) VALUES (@name)";
                try
                {
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    CMD.Parameters.AddWithValue("@name", TxtCatName.Text);
                    int res = CMD.ExecuteNonQuery();
                    if (res > 0)
                    {

                    }
                    else
                    {

                    }
                }
                catch (SqlException E)
                {

                }
            }
        }

        protected void btnDelCat_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "DELETE Category WHERE cat_id=@id";
                try
                {
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    CMD.Parameters.AddWithValue("@id", DdlDelCat.SelectedValue);
                    int res = CMD.ExecuteNonQuery();
                    if (res > 0)
                    {

                    }
                    else
                    {

                    }
                }
                catch (SqlException E)
                {

                }
            }
        }

        protected void btnUpdCat_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "Update Category SET cat_name=@name WHERE cat_id=@id";
                try
                {
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    CMD.Parameters.AddWithValue("@name", TxtUpdCatName.Text);
                    CMD.Parameters.AddWithValue("@id", DdlUpdCat.SelectedValue);
                    int res = CMD.ExecuteNonQuery();
                    if (res > 0)
                    {

                    }
                    else
                    {

                    }
                }
                catch (SqlException E)
                {

                }
            }
        }

        protected void DdlUpdCat_SelectedIndexChanged(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "SELECT * FROM Category WHERE cat_id=@id";
                try
                {
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    CMD.Parameters.AddWithValue("@id", DdlUpdCat.SelectedValue);
                    SqlDataReader SD = CMD.ExecuteReader();
                    while (SD.Read())
                    {
                        TxtUpdCatName.Text = SD["cat_name"].ToString();
                    }
                }
                catch (SqlException E)
                {

                }
            }
        
    }
    }
}