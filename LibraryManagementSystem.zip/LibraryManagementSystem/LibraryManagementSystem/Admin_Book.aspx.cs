﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LibraryManagementSystem
{
    public partial class Admin_Book : System.Web.UI.Page
    {
        static string connString = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btnAddBook_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "INSERT INTO [dbo].[Book] ([book_name], [ISBN], [auth_id], [cat_id], [pub_id], [b_quantity]) VALUES (@name, @isbn, @aid, @cid, @pid, 50)";
                try
                {
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    CMD.Parameters.AddWithValue("@name", TxtAddName.Text);
                    CMD.Parameters.AddWithValue("@isbn", TxtAddISBN.Text.ToString());
                    CMD.Parameters.AddWithValue("@aid", DdlAddAuth.SelectedValue);
                    CMD.Parameters.AddWithValue("@cid", DdlAddCat.SelectedValue);
                    CMD.Parameters.AddWithValue("@pid", DdlAddPub.SelectedValue);
                    int res = CMD.ExecuteNonQuery();
                    if (res > 0)
                    {

                    }
                    else
                    {

                    }
                }
                catch (SqlException E)
                {

                }
            }
        }


        protected void btnUpdBook_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "Update Book SET book_name=@name, isbn=@isbn WHERE b_id=@id";
                try
                {
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    CMD.Parameters.AddWithValue("@name", TxtUpdName.Text);
                    CMD.Parameters.AddWithValue("@isbn", TxtUpdISBN.Text);
                    //CMD.Parameters.AddWithValue("@aid", DdlUpdAuth.SelectedValue);
                    //CMD.Parameters.AddWithValue("@cid", DdlUpdCat.SelectedValue);
                    //CMD.Parameters.AddWithValue("@pid", DdlUpdPub.SelectedValue);
                    CMD.Parameters.AddWithValue("@id", DdlUpdBookID.SelectedValue);
                    int res = CMD.ExecuteNonQuery();
                    if (res > 0)
                    {

                    }
                    else
                    {

                    }
                }
                catch (SqlException E)
                {

                }
            }
        }

        protected void DdlUpdBookID_SelectedIndexChanged(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "SELECT * FROM Book WHERE b_id=@id";
                try
                {
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    CMD.Parameters.AddWithValue("@id", DdlUpdBookID.SelectedValue);
                    SqlDataReader SD = CMD.ExecuteReader();
                    while (SD.Read())
                    {
                        TxtUpdName.Text = SD["book_name"].ToString();
                        TxtUpdISBN.Text = SD["isbn"].ToString();
                        //DdlUpdAuth.Items.FindByValue(SD["auth_id"].ToString()).Selected = true;
                        //DdlUpdCat.Items.FindByValue(SD["cat_id"].ToString()).Selected = true;
                        //DdlUpdPub.Items.FindByValue(SD["pub_id"].ToString()).Selected = true;
                    }
                }
                catch (SqlException E)
                {

                }
            }
        }

        protected void BtnDeleteBook_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "DELETE Book WHERE b_id=@id";
                try
                {
                    conn.Open();
                    SqlCommand CMD = new SqlCommand(query, conn);
                    CMD.Parameters.AddWithValue("@id", DdlDelBook.SelectedValue);
                    int res = CMD.ExecuteNonQuery();
                    if (res > 0)
                    {

                    }
                    else
                    {

                    }
                }
                catch (SqlException E)
                {

                }
            }
        }
    }
}